// Header.js

import React, { useState } from "react";
import logo from "../assets/logo.jpeg"; // Import the logo

const Header = ({ doctors, handleSearch }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const handleChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    handleSearch(searchTerm);
  };

  return (
    <header className="header-container">
      <div className="logo-container">
        <img src={logo} alt="Logo" className="logo" /> {/* Use the logo */}
      </div>

      <div className="search-container">
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={searchTerm}
            onChange={handleChange}
            placeholder="Search by name or specialty"
          />
          <button type="submit">Search</button>
        </form>
      </div>

      <div className="doctor-list-container">
        <h2>Doctor List</h2>
        <ul>
          {doctors.map((doctor) => (
            <li key={doctor.id}>
              <h3>{doctor.name}</h3>
              <p>Specialty: {doctor.specialty}</p>
              <p>Rating: {doctor.rating}</p>
              {/* Add additional information like location or insurances */}
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
};

export default Header;
