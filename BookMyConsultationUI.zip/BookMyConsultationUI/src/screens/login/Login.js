// Login.js

import React, { useState } from "react";
import { FormControl, InputLabel, Input, Button } from "@material-ui/core";

const Login = ({ onClose }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");

  const handleLogin = () => {
    // Validate email and password
    if (!email) {
      setEmailError("Please fill out this field");
      return;
    } else {
      setEmailError("");
    }
    // Send login request to backend
    // Replace this with actual API call
    console.log("Logging in with:", email, password);
    // Close modal
    onClose();
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
    // Reset email error when user starts typing
    setEmailError("");
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  return (
    <div>
      <FormControl>
        <InputLabel>Email</InputLabel>
        <Input type="email" value={email} onChange={handleEmailChange} />
        {emailError && <span className="error">{emailError}</span>}
      </FormControl>
      <FormControl>
        <InputLabel>Password</InputLabel>
        <Input
          type="password"
          value={password}
          onChange={handlePasswordChange}
        />
      </FormControl>
      <Button variant="contained" color="primary" onClick={handleLogin}>
        LOGIN
      </Button>
    </div>
  );
};

export default Login;
