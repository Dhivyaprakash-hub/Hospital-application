import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
} from "@material-ui/core";

const DoctorDetails = ({ doctor, onClose }) => {
  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Doctor Details</DialogTitle>
      <DialogContent>
        <Typography>Name: {doctor.name}</Typography>
        <Typography>Total Experience: {doctor.experience}</Typography>
        <Typography>Speciality: {doctor.speciality}</Typography>
        <Typography>Date of Birth: {doctor.dateOfBirth}</Typography>
        <Typography>City: {doctor.city}</Typography>
        <Typography>Email: {doctor.email}</Typography>
        <Typography>Mobile: {doctor.mobile}</Typography>
        <Typography>Rating: {doctor.rating}</Typography>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default DoctorDetails;
