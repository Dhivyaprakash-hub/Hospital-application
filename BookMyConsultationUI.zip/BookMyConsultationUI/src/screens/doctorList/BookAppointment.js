import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Select,
  MenuItem,
} from "@material-ui/core";

const BookAppointment = ({ doctorName, onClose }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTimeSlot, setSelectedTimeSlot] = useState("");
  const [medicalHistory, setMedicalHistory] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [error, setError] = useState("");

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  const handleTimeSlotChange = (event) => {
    setSelectedTimeSlot(event.target.value);
  };

  const handleBookAppointment = () => {
    // Validation
    if (!selectedTimeSlot) {
      setError("Please select a time slot");
      return;
    }
    // Logic for booking appointment
  };

  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Book an Appointment</DialogTitle>
      <DialogContent>
        <TextField
          label="Doctor's Name"
          value={doctorName}
          disabled
          fullWidth
        />
        <TextField
          label="Select Date"
          type="date"
          value={selectedDate.toISOString().split("T")[0]}
          onChange={(e) => handleDateChange(new Date(e.target.value))}
          fullWidth
        />
        <Select
          value={selectedTimeSlot}
          onChange={handleTimeSlotChange}
          fullWidth
        >
          {/* Time slot options */}
        </Select>
        {error && <Typography style={{ color: "red" }}>{error}</Typography>}
        <TextField
          label="Medical History"
          value={medicalHistory}
          onChange={(e) => setMedicalHistory(e.target.value)}
          fullWidth
        />
        <TextField
          label="Symptoms"
          value={symptoms}
          onChange={(e) => setSymptoms(e.target.value)}
          fullWidth
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleBookAppointment} color="primary">
          Book
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default BookAppointment;
