// DoctorList.js

import React, { useState } from "react";
import { Paper, Typography, Button, Select, MenuItem } from "@material-ui/core";

const DoctorList = () => {
  const [selectedSpeciality, setSelectedSpeciality] = useState("");
  const [doctors, setDoctors] = useState([]);

  const handleChangeSpeciality = (event) => {
    setSelectedSpeciality(event.target.value);
    // Filter doctors based on selected speciality and update doctors state
  };

  const handleBookAppointment = (doctorId) => {
    // Logic for booking appointment
  };

  const handleViewDetails = (doctorId) => {
    // Logic for viewing doctor details
  };

  return (
    <div className="doctor-list-container">
      <Select value={selectedSpeciality} onChange={handleChangeSpeciality}>
        {/* Dropdown options for specialities */}
      </Select>
      {doctors.map((doctor) => (
        <Paper key={doctor.id} className="doctor-item">
          <Typography>{doctor.name}</Typography>
          <Typography>{doctor.speciality}</Typography>
          <Typography>{doctor.rating}</Typography>
          <Button onClick={() => handleBookAppointment(doctor.id)}>
            BOOK APPOINTMENT
          </Button>
          <Button
            onClick={() => handleViewDetails(doctor.id)}
            style={{ backgroundColor: "green" }}
          >
            VIEW DETAILS
          </Button>
        </Paper>
      ))}
    </div>
  );
};

export default DoctorList;
