import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
} from "@material-ui/core";

const RateAppointment = ({ onClose }) => {
  const [rating, setRating] = useState(0);
  const [comments, setComments] = useState("");
  const [error, setError] = useState("");

  const handleRatingChange = (event) => {
    setRating(event.target.value);
  };

  const handleRateAppointment = () => {
    // Validation
    if (rating === 0) {
      setError("Submit a rating");
      return;
    }
    // Logic for submitting rating
  };

  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle style={{ backgroundColor: "#6a1b9a", color: "#ffffff" }}>
        Rate an Appointment
      </DialogTitle>
      <DialogContent>
        <TextField
          label="Comments"
          value={comments}
          onChange={(e) => setComments(e.target.value)}
          fullWidth
          style={{ marginBottom: "20px" }}
        />
        <div>
          <Typography variant="subtitle1">Rating:</Typography>
          <input
            type="number"
            value={rating}
            onChange={handleRatingChange}
            min={1}
            max={5}
            style={{ marginRight: "10px" }}
          />
          {[1, 2, 3, 4, 5].map((value) => (
            <label key={value}>
              <input type="radio" value={value} onChange={handleRatingChange} />
              {value}
            </label>
          ))}
        </div>
        {error && (
          <Typography style={{ color: "red", marginBottom: "20px" }}>
            {error}
          </Typography>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleRateAppointment} color="primary">
          Submit
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default RateAppointment;
