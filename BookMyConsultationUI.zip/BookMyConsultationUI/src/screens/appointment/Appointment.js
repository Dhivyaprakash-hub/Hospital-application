import React from "react";
import { Typography, Paper } from "@material-ui/core";

const Appointment = () => {
  // Assume appointments is an array of appointment objects
  const appointments = [];

  return (
    <div>
      {appointments.length === 0 ? (
        <Typography variant="h6">Login to see appointments</Typography>
      ) : (
        appointments.map((appointment) => (
          <Paper
            key={appointment.id}
            style={{ margin: "15px", padding: "20px", cursor: "pointer" }}
          >
            <Typography variant="h6">{appointment.doctorName}</Typography>
            <Typography>{appointment.appointmentDate}</Typography>
            {appointment.symptoms && (
              <Typography>{appointment.symptoms}</Typography>
            )}
            {appointment.medicalHistory && (
              <Typography>{appointment.medicalHistory}</Typography>
            )}
            <button>Rate Appointment</button>
          </Paper>
        ))
      )}
    </div>
  );
};

export default Appointment;
