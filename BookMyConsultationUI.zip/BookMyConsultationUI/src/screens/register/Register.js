import React, { useState } from "react";
import { FormControl, InputLabel, Input, Button } from "@material-ui/core";

const Register = ({ onClose }) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [emailError, setEmailError] = useState("");
  const [contactNumberError, setContactNumberError] = useState("");

  const handleRegister = () => {
    // Validate form fields
    if (!firstName || !lastName || !email || !password || !contactNumber) {
      // Display error message if any field is empty
      console.log("Please fill out all fields");
      return;
    }

    // Perform email validation
    if (!validateEmail(email)) {
      setEmailError("Enter valid Email");
      return;
    } else {
      setEmailError("");
    }

    // Perform mobile number validation
    if (!validateMobileNumber(contactNumber)) {
      setContactNumberError("Enter valid mobile number");
      return;
    } else {
      setContactNumberError("");
    }

    // Send registration request to backend
    // Replace this with actual API call
    console.log("Registering user with:", {
      firstName,
      lastName,
      email,
      password,
      contactNumber,
    });
    // Display registration success message
    console.log("Registration Successful");
    // Close modal
    onClose();
  };

  const validateEmail = (email) => {
    // Implement email validation logic
    // Example: Check if email matches a valid format using regular expressions
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validateMobileNumber = (number) => {
    // Implement mobile number validation logic
    // Example: Check if number contains only digits and has the correct length
    return /^\d{10}$/.test(number);
  };

  return (
    <div>
      <FormControl>
        <InputLabel>First Name</InputLabel>
        <Input
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
      </FormControl>
      <FormControl>
        <InputLabel>Last Name</InputLabel>
        <Input value={lastName} onChange={(e) => setLastName(e.target.value)} />
      </FormControl>
      <FormControl>
        <InputLabel>Email</InputLabel>
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {emailError && <span className="error">{emailError}</span>}
      </FormControl>
      <FormControl>
        <InputLabel>Password</InputLabel>
        <Input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </FormControl>
      <FormControl>
        <InputLabel>Contact Number</InputLabel>
        <Input
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
        />
        {contactNumberError && (
          <span className="error">{contactNumberError}</span>
        )}
      </FormControl>
      <Button variant="contained" color="primary" onClick={handleRegister}>
        REGISTER
      </Button>
    </div>
  );
};

export default Register;
