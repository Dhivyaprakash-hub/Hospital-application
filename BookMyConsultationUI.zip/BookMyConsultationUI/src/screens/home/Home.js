import React, { useState, useEffect } from "react";
import "./Home.css";
import { Link } from "react-router-dom"; // Import Link for navigation

const Home = () => {
  // State to manage the active tab
  const [activeTab, setActiveTab] = useState("DOCTORS");

  // State to manage doctor data (replace with your API call)
  const [doctors] = useState([]);

  // Function to handle tab click
  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  // Function to fetch doctor data (replace with your API call)
  const fetchDoctors = async () => {
    console.log("Fetching doctors from:", "http://localhost:8080/doctors");
    const response = await fetch("http://localhost:8080/doctors");
    console.log("API response:", response);
  };

  // Fetch doctor data on component mount
  useEffect(() => {
    fetchDoctors();
  }, []);

  // JSX for the home page UI
  return (
    <div className="home-container">
      {/* Logo (replace with your logo image) */}
      <img src="logo.jpeg" alt="Doctor Finder Logo" className="logo" />

      {/* Title */}
      <h1 className="title">Doctor Finder</h1>

      {/* Login button */}
      <Link to="http://localhost:8080/auth/login" className="login-button">
        <button>LOGIN</button>
      </Link>

      {/* Tab component */}
      <div className="tabs">
        <button
          className={activeTab === "DOCTORS" ? "active" : ""}
          onClick={() => handleTabClick("DOCTORS")}
        >
          DOCTORS
        </button>
        <button
          className={activeTab === "APPOINTMENT" ? "active" : ""}
          onClick={() => handleTabClick("APPOINTMENT")}
        >
          APPOINTMENT (Login Required)
        </button>
      </div>

      {/* Content based on the active tab */}
      {activeTab === "DOCTORS" && (
        <div className="doctors">
          {/* Search bar component */}
          <input type="text" placeholder="Search Doctors..." />

          {/* Doctor list component */}
          <ul>
            {doctors.map((doctor) => (
              <li key={doctor.id}>
                <div className="doctor-info">
                  <h3>{doctor.name}</h3>
                  <p>{doctor.speciality}</p>
                </div>
                <div className="doctor-actions">
                  <button>BOOK APPOINTMENT</button>
                  <button>VIEW DETAILS</button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
      {activeTab === "APPOINTMENT" && (
        <div className="appointments">
          {/* Implement appointment list component (requires login) */}
          <p>Login to view your appointments</p>
        </div>
      )}
    </div>
  );
};

export default Home;
