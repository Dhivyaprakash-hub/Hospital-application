package com.upgrad.bookmyconsultation.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@SuppressWarnings("serial")
public class InvalidInputException extends Exception implements Serializable{	
    private List<String> attributeNames;
    private List<String> errorFields;

    public InvalidInputException(String message) {
        super(message);
    }

    public InvalidInputException(String message, List<String> attributeNames) {
        super(message);
        this.attributeNames = attributeNames;
    }

	public List<String> getAttributeNames() {
		return attributeNames;
	}

	public void setAttributeNames(List<String> attributeNames) {
		this.attributeNames = attributeNames;
	}
	
	public InvalidInputException(List<String> errorFields) {
        super("Invalid input fields: " + String.join(", ", errorFields));
        this.errorFields = errorFields;
    }
	
	public List<String> getErrorFields() {
        return errorFields;
    }
}
