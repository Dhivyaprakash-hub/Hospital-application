package com.upgrad.bookmyconsultation.exception;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UnauthorizedException extends RestException  implements Serializable{

    public UnauthorizedException(final ErrorCode errorCode, final Object... parameters){
        super(errorCode, parameters);
    }

}
