package com.upgrad.bookmyconsultation.exception;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ResourceUnAvailableException extends RuntimeException implements Serializable{
	public ResourceUnAvailableException(String message) {
        super(message);
    }
}