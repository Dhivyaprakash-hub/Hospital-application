package com.upgrad.bookmyconsultation.exception;

import java.io.Serializable;

@SuppressWarnings("serial")
public class SlotUnavailableException extends RuntimeException  implements Serializable{
	public SlotUnavailableException(String message) {
        super(message);
    }
}