package com.upgrad.bookmyconsultation.service;

import com.upgrad.bookmyconsultation.entity.Doctor;
import com.upgrad.bookmyconsultation.entity.Rating;
import com.upgrad.bookmyconsultation.repository.DoctorRepository;
import com.upgrad.bookmyconsultation.repository.RatingsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;



@Service
public class RatingsService {

	@Autowired
	private RatingsRepository ratingsRepository;

	@Autowired
	private DoctorRepository doctorRepository;
	
	public void submitRatings(Rating rating) {
		rating.setId(UUID.randomUUID().toString());
		ratingsRepository.save(rating);

		Doctor doctor = doctorRepository.findById(rating.getDoctorId())
				.orElseThrow(() -> new RuntimeException("Doctor not found"));

		List<Rating> ratings = ratingsRepository.findByDoctorId(rating.getDoctorId());
		double averageRating = ratings.stream().mapToInt(Rating::getRating).average().orElse(0.0);

		doctor.setAverageRating(averageRating);
		doctorRepository.save(doctor);
		}
	}